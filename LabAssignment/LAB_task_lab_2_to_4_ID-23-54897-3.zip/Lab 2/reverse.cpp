#include <bits/stdc++.h>
using namespace std ;
int main(){


int arr[10];

for(int  i= 0; i<10 ;i++)
{

    cout<<"Enter "<<i+1<<" number = ";
    cin>>arr[i];
    cout<<endl;




}
vector <int> vec ;
cout<<"Your reverser array is = ";

for(int  i= 9; i>=0 ;i--)
{

    cout<<arr[i]<<" ";




}









}



    

